import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// PORT SETTINGS: this app always runs on 5180.
// strictPort: true means it stops with an error if 5180 is busy,
// instead of quietly taking another port (like your Focus Board's).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5180,
    strictPort: true,
  },
  preview: {
    port: 5180,
    strictPort: true,
  },
})
