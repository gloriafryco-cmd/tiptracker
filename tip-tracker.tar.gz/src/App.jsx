import { useEffect, useState } from 'react'
import { loadState, saveState, newJob } from './store.js'
import QuickAdd from './screens/QuickAdd.jsx'
import Result from './screens/Result.jsx'
import History from './screens/History.jsx'
import Regulars from './screens/Regulars.jsx'
import Settings from './screens/Settings.jsx'
import Quiz from './screens/Quiz.jsx'

// APP SHELL: bottom tabs, saving, and which screen is showing.
export default function App() {
  const [state, setState] = useState(loadState)
  const [tab, setTab] = useState('add')
  const [quiz, setQuiz] = useState(null) // { jobId } to redo a job, { jobId: null } for a new job
  const [result, setResult] = useState(null) // id of the shift just saved
  const [editing, setEditing] = useState(null) // shift being edited from History

  useEffect(() => saveState(state), [state])

  // DISPLAY SETTINGS: dark mode and large text
  useEffect(() => {
    const root = document.documentElement
    if (state.prefs.theme === 'auto') root.removeAttribute('data-theme')
    else root.setAttribute('data-theme', state.prefs.theme)
    root.classList.toggle('large-text', !!state.prefs.largeText)
  }, [state.prefs])

  // update(fn): fn gets a copy of the data, changes it, and it is saved.
  const update = (fn) =>
    setState((s) => {
      const copy = structuredClone(s)
      fn(copy)
      return copy
    })

  const activeJobs = state.jobs.filter((j) => !j.archived)

  // FIRST LAUNCH: no jobs yet
  if (state.jobs.length === 0 && !quiz) {
    return (
      <main className="app">
        <section className="welcome">
          <h1>Tip Tracker</h1>
          <p className="lead">How much did I make? How much did I sell? How am I doing this week?</p>
          <p>Answer a few questions about your job so the app works the way your restaurant does. Every question can be skipped.</p>
          <button className="primary big" onClick={() => setQuiz({ jobId: null })}>
            Set up my job
          </button>
          <button
            className="ghost"
            onClick={() => update((s) => { s.jobs.push(newJob('My job')) })}
          >
            Skip for now
          </button>
        </section>
      </main>
    )
  }

  if (quiz) {
    return (
      <main className="app">
        <Quiz
          state={state}
          jobId={quiz.jobId}
          onCancel={() => setQuiz(null)}
          onSave={(job) => {
            update((s) => {
              const i = s.jobs.findIndex((j) => j.id === job.id)
              if (i >= 0) s.jobs[i] = job
              else s.jobs.push(job)
            })
            setQuiz(null)
          }}
        />
      </main>
    )
  }

  let screen
  if (result) {
    screen = (
      <Result
        state={state}
        shiftId={result}
        update={update}
        onAgain={() => { setResult(null); setTab('add') }}
        onDone={() => { setResult(null); setTab('history') }}
      />
    )
  } else if (editing) {
    screen = (
      <QuickAdd
        key={editing}
        state={state}
        update={update}
        editId={editing}
        onSetup={(jobId) => setQuiz({ jobId })}
        onSaved={() => { setEditing(null); setTab('history') }}
        onCancel={() => setEditing(null)}
      />
    )
  } else if (tab === 'add') {
    screen = (
      <QuickAdd
        key="new"
        state={state}
        update={update}
        onSetup={(jobId) => setQuiz({ jobId })}
        onSaved={(id) => setResult(id)}
      />
    )
  } else if (tab === 'history') {
    screen = <History state={state} update={update} onEdit={setEditing} />
  } else if (tab === 'regulars') {
    screen = <Regulars state={state} update={update} />
  } else {
    screen = (
      <Settings
        state={state}
        update={update}
        onRedo={(jobId) => setQuiz({ jobId })}
        onAddJob={() => setQuiz({ jobId: null })}
      />
    )
  }

  const tabs = [
    ['add', 'Quick Add'],
    ['history', 'History'],
    ['regulars', 'Regulars'],
    ['settings', 'Settings'],
  ]

  return (
    <div className="app">
      <main className="content">{activeJobs.length || tab === 'settings' ? screen : (
        <section className="card">
          <h2>All your jobs are archived</h2>
          <p>Go to Settings to bring one back or add a new job.</p>
        </section>
      )}</main>
      <nav className="tabs">
        {tabs.map(([id, label]) => (
          <button
            key={id}
            className={tab === id && !result && !editing ? 'on' : ''}
            onClick={() => { setResult(null); setEditing(null); setTab(id) }}
          >
            {label}
          </button>
        ))}
      </nav>
    </div>
  )
}
