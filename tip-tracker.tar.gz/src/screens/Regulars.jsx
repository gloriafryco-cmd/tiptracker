import { useState } from 'react'
import { uid } from '../store.js'

// REGULARS: private guest memory. Name and usual order are the main fields.
export default function Regulars({ state, update }) {
  const [name, setName] = useState('')
  const [open, setOpen] = useState(null)

  const add = () => {
    const n = name.trim()
    if (!n) return
    update((s) => { s.regulars.push({ id: uid(), name: n, order: '', table: '', details: '' }) })
    setName('')
  }
  const edit = (id, patch) =>
    update((s) => { Object.assign(s.regulars.find((r) => r.id === id), patch) })

  return (
    <section>
      <h2>Regulars</h2>
      <p className="privacy">
        <strong>Keep it friendly, keep it private.</strong> Save only things that help you give great service.
        Don't store phone numbers, emails, addresses, payment info or health details. These notes stay on this device.
      </p>
      <div className="row">
        <input value={name} placeholder="Name" onChange={(e) => setName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && add()} />
        <button className="primary" onClick={add}>Add</button>
      </div>
      {state.regulars.length === 0 && <p className="empty">No regulars yet. Add a name above.</p>}
      <ul className="list">
        {state.regulars.map((r) => (
          <li key={r.id} className="stack">
            <div className="row-between">
              <button className="link" onClick={() => setOpen(open === r.id ? null : r.id)}>
                <strong>{r.name}</strong>{r.order && ` · ${r.order}`}
              </button>
              <button
                className="link danger"
                onClick={() => confirm(`Delete ${r.name}?`) && update((s) => { s.regulars = s.regulars.filter((x) => x.id !== r.id) })}
              >
                Delete
              </button>
            </div>
            {open === r.id && (
              <>
                <label className="field"><span>Usual order</span>
                  <input value={r.order} onChange={(e) => edit(r.id, { order: e.target.value })} /></label>
                <label className="field"><span>Favorite table</span>
                  <input value={r.table} onChange={(e) => edit(r.id, { table: e.target.value })} /></label>
                <label className="field"><span>Fun details (birthday, dog's name...)</span>
                  <input value={r.details} onChange={(e) => edit(r.id, { details: e.target.value })} /></label>
              </>
            )}
          </li>
        ))}
      </ul>
    </section>
  )
}
