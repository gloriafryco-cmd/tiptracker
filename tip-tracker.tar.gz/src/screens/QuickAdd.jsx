import { useState } from 'react'
import {
  uid, today, num, money, prettyDate, hoursFromTimes, fmtHours,
  shiftTips, tipsPerHour, perHourWithWage,
} from '../store.js'

// QUICK ADD: the home screen. Three screens, every one can be submitted.
// 1 = How much did I make? (needed)  2 = How much did I sell?  3 = Shift vibes

const SHIFT_TYPES = ['Breakfast', 'Lunch', 'Dinner', 'Late night', 'Event / private party', 'Double']
const WEATHER = ['Sunny', 'Cloudy', 'Rainy', 'Snowy', 'Hot', 'Cold']
const OFF_TYPES = ['Day off', 'Sick', 'Vacation']

function blankShift(state) {
  const jobs = state.jobs.filter((j) => !j.archived)
  const job = jobs.find((j) => j.id === state.last.jobId) || jobs[0]
  const role = job?.roles.find((r) => r.id === state.last.roleId) || job?.roles[0]
  return {
    id: null,
    date: today(),
    jobId: job?.id,
    roleId: role?.id,
    cash: '', card: '', autoGrat: '',
    hours: '', hh: '', mm: '', useTimes: false, start: '', end: '',
    useWage: !!state.last.useWage,
    sales: '', covers: '', tipOut: '',
    shiftType: [], weather: '', events: '', section: '',
    regularsSeen: [], vibe: 0, note: '',
  }
}

export default function QuickAdd({ state, update, editId, onSaved, onCancel, onSetup }) {
  const editing = editId ? state.shifts.find((s) => s.id === editId) : null
  const [f, setF] = useState(() => {
    if (!editing) return blankShift(state)
    const h = num(editing.hours)
    return { ...blankShift(state), ...editing, hh: Math.floor(h), mm: Math.round((h - Math.floor(h)) * 60) }
  })
  const [page, setPage] = useState(1)
  const [offOpen, setOffOpen] = useState(false)
  const [offMsg, setOffMsg] = useState('')
  const [newRegular, setNewRegular] = useState('')
  const [error, setError] = useState('')
  const set = (patch) => setF((x) => ({ ...x, ...patch }))

  const jobs = state.jobs.filter((j) => !j.archived || j.id === f.jobId)
  const job = state.jobs.find((j) => j.id === f.jobId) || jobs[0]
  const role = job?.roles.find((r) => r.id === f.roleId) || job?.roles[0]

  // HOURS: typed as 6.5, as hours + minutes, or worked out from start/end times
  const hours = f.useTimes
    ? hoursFromTimes(f.start, f.end)
    : job?.hoursFormat === 'hm'
      ? num(f.hh) + num(f.mm) / 60
      : num(f.hours)

  // Editing an old shift keeps the hourly wage it was saved with.
  const wage = editing && editing.roleId === role?.id ? num(editing.wage) : num(role?.wage)
  const preview = { ...f, hours, wage }
  const total = shiftTips(preview)

  // SAVE SHIFT: used by every Submit button
  const submit = () => {
    if (!job) return
    if (!(hours > 0)) {
      setPage(1)
      setError('Add your hours so the app can work out tips per hour.')
      return
    }
    const id = f.id || uid()
    const shift = {
      id,
      date: f.date,
      jobId: job.id,
      roleId: role?.id,
      roleName: role?.name || '',
      cash: num(f.cash), card: num(f.card), autoGrat: num(f.autoGrat),
      hours,
      useTimes: f.useTimes, start: f.start, end: f.end,
      useWage: f.useWage,
      wage, // hourly wage saved with the shift, so later wage changes don't rewrite the past
      sales: f.sales === '' ? '' : num(f.sales),
      salesType: job.salesType,
      covers: f.covers === '' ? '' : num(f.covers),
      tipOut: f.tipOut === '' ? '' : num(f.tipOut),
      shiftType: f.shiftType, weather: f.weather, events: f.events, section: f.section,
      regularsSeen: f.regularsSeen, vibe: f.vibe, note: f.note,
    }
    update((s) => {
      const i = s.shifts.findIndex((x) => x.id === id)
      if (i >= 0) s.shifts[i] = shift
      else s.shifts.push(shift)
      s.last = { jobId: job.id, roleId: role?.id, useWage: f.useWage }
    })
    onSaved(id)
  }

  // DAY OFF BUTTON
  const markOff = (type) => {
    update((s) => {
      s.timeOff.push({ id: uid(), jobId: job.id, start: f.date, end: f.date, type })
    })
    setOffOpen(false)
    setOffMsg(`Saved: ${prettyDate(f.date)} marked as ${type.toLowerCase()} at ${job.name}.`)
  }

  const toggleIn = (list, v) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v])

  const addRegular = () => {
    const name = newRegular.trim()
    if (!name) return
    const id = uid()
    update((s) => { s.regulars.push({ id, name, order: '', table: '', details: '' }) })
    set({ regularsSeen: [...f.regularsSeen, id] })
    setNewRegular('')
  }

  if (!job) return null

  return (
    <section className="quick-add">
      {!editing && !job.setupDone && (
        <div className="banner">
          Finish setting up {job.name} so the app matches how your job works.{' '}
          <button className="link" onClick={() => onSetup(job.id)}>Finish setup</button>
        </div>
      )}

      {!editing && page === 1 && (
        <div className="off-row">
          <button className="ghost" onClick={() => setOffOpen(!offOpen)}>I had the day off</button>
          {offOpen && (
            <div className="chips">
              {OFF_TYPES.map((t) => <button key={t} className="chip" onClick={() => markOff(t)}>{t}</button>)}
            </div>
          )}
          {offMsg && <p className="hint">{offMsg}</p>}
        </div>
      )}

      <div className="pager">
        {[1, 2, 3].map((n) => (
          <button key={n} className={page === n ? 'dot on' : 'dot'} onClick={() => setPage(n)} aria-label={`Screen ${n}`} />
        ))}
      </div>

      {/* QUICK ADD SCREEN 1: How much did I make? */}
      {page === 1 && (
        <>
          <h2>{editing ? 'Edit shift' : 'How much did I make?'}</h2>
          <div className="grid2">
            <label className="field">
              <span>Job</span>
              <select
                value={job.id}
                onChange={(e) => {
                  const j = state.jobs.find((x) => x.id === e.target.value)
                  set({ jobId: j.id, roleId: j.roles[0]?.id })
                }}
              >
                {jobs.map((j) => <option key={j.id} value={j.id}>{j.name}</option>)}
              </select>
            </label>
            <label className="field">
              <span>Position</span>
              <select value={role?.id} onChange={(e) => set({ roleId: e.target.value })}>
                {job.roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
            </label>
          </div>
          <label className="field">
            <span>Shift date (the day it started)</span>
            <input type="date" value={f.date} onChange={(e) => set({ date: e.target.value })} />
          </label>
          <div className="grid2">
            <Money label="Cash tips" value={f.cash} onChange={(v) => set({ cash: v })} />
            <Money label="Card tips" value={f.card} onChange={(v) => set({ card: v })} />
          </div>
          {job.trackAutoGrat && (
            <Money label="Auto-gratuity (counts as tips)" value={f.autoGrat} onChange={(v) => set({ autoGrat: v })} />
          )}
          <p className="hint">Enter tips after tip-outs.</p>

          {f.useTimes ? (
            <div className="grid2">
              <label className="field"><span>Start time</span>
                <input type="time" value={f.start} onChange={(e) => set({ start: e.target.value })} /></label>
              <label className="field"><span>End time</span>
                <input type="time" value={f.end} onChange={(e) => set({ end: e.target.value })} /></label>
            </div>
          ) : job.hoursFormat === 'hm' ? (
            <div className="grid2">
              <label className="field"><span>Hours</span>
                <input type="number" inputMode="numeric" min="0" value={f.hh} onChange={(e) => set({ hh: e.target.value })} /></label>
              <label className="field"><span>Minutes</span>
                <input type="number" inputMode="numeric" min="0" max="59" value={f.mm} onChange={(e) => set({ mm: e.target.value })} /></label>
            </div>
          ) : (
            <label className="field"><span>Hours worked</span>
              <input type="number" inputMode="decimal" min="0" step="0.25" placeholder="6.5" value={f.hours} onChange={(e) => set({ hours: e.target.value })} /></label>
          )}
          <button className="link" onClick={() => set({ useTimes: !f.useTimes })}>
            {f.useTimes ? 'Type hours instead' : 'Use start and end times instead'}
          </button>
          {f.useTimes && hours > 0 && <p className="hint">That's {fmtHours(hours, job.hoursFormat)}.</p>}

          <label className="switch">
            <input type="checkbox" checked={f.useWage} onChange={(e) => set({ useWage: e.target.checked })} />
            <span>Include my hourly wage ({money(wage)}/hr as {role?.name})</span>
          </label>

          {/* LIVE TOTALS: tips per hour first, total tips beside it */}
          <div className="totals">
            <div>
              <span className="label">{f.useWage ? 'Per hour (tips + hourly wage)' : 'Tips per hour'}</span>
              <strong className="big-num">{money(f.useWage ? perHourWithWage(preview) : tipsPerHour(preview))}</strong>
            </div>
            <div>
              <span className="label">Total tips this shift</span>
              <strong className="big-num">{money(total)}</strong>
            </div>
          </div>
          {error && <p className="error">{error}</p>}
        </>
      )}

      {/* QUICK ADD SCREEN 2: How much did I sell? */}
      {page === 2 && (
        <>
          <h2>How much did I sell?</h2>
          <p className="hint">Optional. Fill in what you want to track.</p>
          <Money label={`Shift sales (${job.salesType})`} value={f.sales} onChange={(v) => set({ sales: v })} />
          <label className="field"><span>Covers (guests served)</span>
            <input type="number" inputMode="numeric" min="0" value={f.covers} onChange={(e) => set({ covers: e.target.value })} /></label>
          <Money label="Amount I tipped out" value={f.tipOut} onChange={(v) => set({ tipOut: v })} />
          <p className="hint">For your records only. It doesn't change your tips.</p>
          {num(f.sales) > 0 && total > 0 && (
            <p className="hint">Tips are {Math.round((total / num(f.sales)) * 1000) / 10}% of sales this shift.</p>
          )}
        </>
      )}

      {/* QUICK ADD SCREEN 3: Shift vibes */}
      {page === 3 && (
        <>
          <h2>Shift vibes</h2>
          <p className="hint">Optional. Helps you spot what makes a good shift.</p>
          <div className="field">
            <span>Shift type</span>
            <div className="chips">
              {SHIFT_TYPES.map((t) => (
                <button key={t} className={f.shiftType.includes(t) ? 'chip on' : 'chip'} onClick={() => set({ shiftType: toggleIn(f.shiftType, t) })}>{t}</button>
              ))}
            </div>
          </div>
          <div className="field">
            <span>Weather</span>
            <div className="chips">
              {WEATHER.map((w) => (
                <button key={w} className={f.weather === w ? 'chip on' : 'chip'} onClick={() => set({ weather: f.weather === w ? '' : w })}>{w}</button>
              ))}
            </div>
          </div>
          <label className="field"><span>Events (trivia, bingo, the game...)</span>
            <input value={f.events} onChange={(e) => set({ events: e.target.value })} /></label>
          <label className="field"><span>Section or station</span>
            <input value={f.section} onChange={(e) => set({ section: e.target.value })} /></label>
          <div className="field">
            <span>Regulars I saw</span>
            <div className="chips">
              {state.regulars.map((r) => (
                <button key={r.id} className={f.regularsSeen.includes(r.id) ? 'chip on' : 'chip'} onClick={() => set({ regularsSeen: toggleIn(f.regularsSeen, r.id) })}>{r.name}</button>
              ))}
            </div>
            <div className="row">
              <input value={newRegular} placeholder="New regular's name" onChange={(e) => setNewRegular(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addRegular()} />
              <button onClick={addRegular}>Add</button>
            </div>
          </div>
          <div className="field">
            <span>Shift vibe</span>
            <div className="chips">
              {[1, 2, 3, 4, 5].map((n) => (
                <button key={n} className={f.vibe === n ? 'chip on' : 'chip'} onClick={() => set({ vibe: f.vibe === n ? 0 : n })}>{n}</button>
              ))}
            </div>
          </div>
          <label className="field"><span>Note</span>
            <textarea rows="2" value={f.note} onChange={(e) => set({ note: e.target.value })} /></label>
        </>
      )}

      <div className="actions">
        <button className="primary big" onClick={submit}>{editing ? 'Save changes' : 'Submit'}</button>
        {page === 1 && <button className="ghost" onClick={() => setPage(2)}>Next: How much did I sell?</button>}
        {page === 2 && <button className="ghost" onClick={() => setPage(3)}>Next: Shift vibes</button>}
        {page > 1 && <button className="ghost" onClick={() => setPage(page - 1)}>Back</button>}
        {editing && <button className="ghost" onClick={onCancel}>Cancel</button>}
      </div>
    </section>
  )
}

function Money({ label, value, onChange }) {
  return (
    <label className="field">
      <span>{label}</span>
      <div className="money">
        <i>$</i>
        <input type="number" inputMode="decimal" min="0" step="0.01" value={value} onChange={(e) => onChange(e.target.value)} />
      </div>
    </label>
  )
}
