import {
  uid, money, num, prettyDate, fmtHours, today, addDays, toDate,
  shiftTips, tipsPerHour, perHourWithWage, weekProgress,
} from '../store.js'

// RESULT SCREEN: shows right after every Submit.
// This shift first, then "How am I doing this week?"
export default function Result({ state, shiftId, update, onAgain, onDone }) {
  const shift = state.shifts.find((s) => s.id === shiftId)
  if (!shift) return null
  const job = state.jobs.find((j) => j.id === shift.jobId)
  const wk = weekProgress(state, job, shift.date)
  const pct = wk.goal > 0 ? Math.min(100, Math.round((wk.tips / wk.goal) * 100)) : 0
  const left = Math.max(0, wk.goal - wk.tips)

  // PICK-UP-A-SHIFT NUDGE: last 2 days of the week, goal not met, no time off this week
  const daysLeft = Math.round((toDate(wk.range.end) - toDate(today())) / 86400000)
  const showNudge =
    job.nudge && wk.goal > 0 && left > 0 && wk.off === 0 &&
    daysLeft >= 0 && daysLeft <= 1 && wk.range.end >= today()

  // "I'M OFF THIS WEEK": marks the rest of this week as days off
  const offThisWeek = () => {
    const start = shift.date > today() ? shift.date : addDays(today(), 1)
    if (start > wk.range.end) return
    update((s) => {
      s.timeOff.push({ id: uid(), jobId: job.id, start, end: wk.range.end, type: 'Day off' })
    })
  }

  return (
    <section className="result">
      <p className="saved">Saved ✓ {job.name} · {shift.roleName} · {prettyDate(shift.date)}</p>

      <h2>This shift</h2>
      <div className="totals">
        <div>
          <span className="label">{shift.useWage ? 'Per hour (tips + hourly wage)' : 'Tips per hour'}</span>
          <strong className="big-num">{money(shift.useWage ? perHourWithWage(shift) : tipsPerHour(shift))}</strong>
        </div>
        <div>
          <span className="label">Total tips this shift</span>
          <strong className="big-num">{money(shiftTips(shift))}</strong>
        </div>
      </div>
      <p className="hint">
        {fmtHours(num(shift.hours), job.hoursFormat)} worked
        {shift.useWage && ` · ${money(num(shift.wage) * num(shift.hours))} hourly wage`}
      </p>

      <h2>How am I doing this week?</h2>
      <p className="hint">{prettyDate(wk.range.start)} to {prettyDate(wk.range.end)} · {wk.shifts} shift{wk.shifts === 1 ? '' : 's'}</p>
      {wk.goal > 0 ? (
        <>
          <div className="bar"><div style={{ width: `${pct}%` }} /></div>
          <p>
            <strong>{money(wk.tips)}</strong> of {money(wk.goal)} weekly tip goal
            {left > 0 ? ` · ${money(left)} to go` : ' · Goal reached! 🎉'}
          </p>
          {wk.off > 0 && job.goalWhenOff === 'shrink' && (
            <p className="hint">Goal adjusted for {wk.off} day{wk.off === 1 ? '' : 's'} off.</p>
          )}
        </>
      ) : (
        <p><strong>{money(wk.tips)}</strong> in tips this week. Set a weekly tip goal in Settings to see a progress bar.</p>
      )}
      {showNudge && <p className="nudge">Maybe you should pick up a shift ;)</p>}

      <div className="actions">
        <button className="primary" onClick={onAgain}>Log another shift</button>
        <button className="ghost" onClick={onDone}>See history</button>
        {wk.range.end > today() && wk.off === 0 && (
          <button className="ghost" onClick={offThisWeek}>I'm off the rest of this week</button>
        )}
      </div>
    </section>
  )
}
