import { eraseAll } from '../store.js'

// SETTINGS: per-job actions (redo preferences, archive) and display options.
export default function Settings({ state, update, onRedo, onAddJob }) {
  const setPref = (patch) => update((s) => { Object.assign(s.prefs, patch) })
  const setJob = (id, patch) => update((s) => { Object.assign(s.jobs.find((j) => j.id === id), patch) })

  return (
    <section>
      <h2>Settings</h2>

      <h3>My jobs</h3>
      <ul className="list">
        {state.jobs.map((j) => (
          <li key={j.id} className="stack">
            <div className="row-between">
              <strong>{j.name}{j.archived ? ' (archived)' : ''}</strong>
              <span className="hint">{j.roles.map((r) => r.name).join(', ')}</span>
            </div>
            <div className="row-actions">
              <button className="link" onClick={() => onRedo(j.id)}>Redo my job preferences</button>
              <button className="link" onClick={() => setJob(j.id, { archived: !j.archived })}>
                {j.archived ? 'Bring back' : 'Archive'}
              </button>
            </div>
            <label className="switch">
              <input type="checkbox" checked={j.trackAutoGrat} onChange={(e) => setJob(j.id, { trackAutoGrat: e.target.checked })} />
              <span>Show an auto-gratuity line when logging shifts</span>
            </label>
          </li>
        ))}
      </ul>
      <button className="primary" onClick={onAddJob}>Add a job</button>
      <p className="hint">Changes apply from today. Past shifts keep what they were saved with. Jobs are archived, never deleted.</p>

      <h3>Display</h3>
      <label className="field">
        <span>Theme</span>
        <select value={state.prefs.theme} onChange={(e) => setPref({ theme: e.target.value })}>
          <option value="auto">Match my device</option>
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>
      <label className="switch">
        <input type="checkbox" checked={state.prefs.largeText} onChange={(e) => setPref({ largeText: e.target.checked })} />
        <span>Large text</span>
      </label>

      <h3>My data</h3>
      <p className="hint">Everything is saved in this browser on this computer only.</p>
      <button
        className="ghost danger"
        onClick={() => {
          if (confirm('Erase ALL jobs, shifts and regulars? This can\'t be undone.')) {
            eraseAll()
            location.reload()
          }
        }}
      >
        Erase all my data
      </button>
    </section>
  )
}
