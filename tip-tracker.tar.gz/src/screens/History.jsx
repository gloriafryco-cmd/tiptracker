import { useState } from 'react'
import {
  uid, money, num, today, prettyDate, addDays, weekRange, inRange, fmtHours,
  shiftTips, tipsPerHour, paycheckPeriod, toCSV, download,
} from '../store.js'

// HISTORY: shift list, week and month totals, export, paycheck log, time off.
export default function History({ state, update, onEdit }) {
  const [jobFilter, setJobFilter] = useState('all')
  const jobName = (id) => state.jobs.find((j) => j.id === id)?.name || 'Unknown job'
  const shifts = state.shifts
    .filter((s) => jobFilter === 'all' || s.jobId === jobFilter)
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))

  // TOTALS: this week (uses the picked job's week start, Monday for all jobs) and this month
  const weekStart = jobFilter === 'all' ? 1 : state.jobs.find((j) => j.id === jobFilter)?.weekStart ?? 1
  const week = weekRange(today(), weekStart)
  const monthPrefix = today().slice(0, 7)
  const sum = (list) => list.reduce((a, s) => a + shiftTips(s), 0)
  const hrs = (list) => list.reduce((a, s) => a + num(s.hours), 0)
  const thisWeek = shifts.filter((s) => inRange(s.date, week))
  const thisMonth = shifts.filter((s) => s.date.startsWith(monthPrefix))
  const avg = hrs(shifts) > 0 ? sum(shifts) / hrs(shifts) : 0

  return (
    <section className="history">
      <h2>History</h2>
      <label className="field">
        <span>Show</span>
        <select value={jobFilter} onChange={(e) => setJobFilter(e.target.value)}>
          <option value="all">All jobs</option>
          {state.jobs.map((j) => <option key={j.id} value={j.id}>{j.name}{j.archived ? ' (archived)' : ''}</option>)}
        </select>
      </label>

      <div className="stats">
        <div><span className="label">This week</span><strong>{money(sum(thisWeek))}</strong></div>
        <div><span className="label">This month</span><strong>{money(sum(thisMonth))}</strong></div>
        <div><span className="label">Average tips per hour</span><strong>{money(avg)}</strong></div>
      </div>

      {/* SHIFT LIST */}
      {shifts.length === 0 ? (
        <p className="empty">No shifts yet. Your first one shows up here after you submit it.</p>
      ) : (
        <ul className="list">
          {shifts.map((s) => {
            const job = state.jobs.find((j) => j.id === s.jobId)
            return (
              <li key={s.id}>
                <div>
                  <strong>{prettyDate(s.date)}</strong> · {jobName(s.jobId)} · {s.roleName}
                  <div className="hint">
                    {money(shiftTips(s))} tips · {fmtHours(num(s.hours), job?.hoursFormat)} · {money(tipsPerHour(s))}/hr
                    {s.vibe ? ` · vibe ${s.vibe}/5` : ''}
                  </div>
                </div>
                <div className="row-actions">
                  <button className="link" onClick={() => onEdit(s.id)}>Edit</button>
                  <button
                    className="link danger"
                    onClick={() => {
                      if (confirm(`Delete the ${prettyDate(s.date)} shift? This can't be undone.`)) {
                        update((st) => { st.shifts = st.shifts.filter((x) => x.id !== s.id) })
                      }
                    }}
                  >
                    Delete
                  </button>
                </div>
              </li>
            )
          })}
        </ul>
      )}

      <Export state={state} jobFilter={jobFilter} />
      <PaycheckLog state={state} update={update} />
      <TimeOffList state={state} update={update} jobName={jobName} />
    </section>
  )
}

// EXPORT: every shift in a date range as a spreadsheet file (CSV).
// Doubles as "tip proof" to show a manager the card tips for a pay window.
function Export({ state, jobFilter }) {
  const [from, setFrom] = useState(addDays(today(), -30))
  const [to, setTo] = useState(today())
  const run = () => {
    const rows = [[
      'Date', 'Job', 'Position', 'Cash tips', 'Card tips', 'Auto-gratuity', 'Total tips',
      'Hours', 'Tips per hour', 'Hourly wage', 'Sales', 'Sales type', 'Covers', 'Tipped out',
      'Shift type', 'Weather', 'Events', 'Section', 'Vibe', 'Note',
    ]]
    state.shifts
      .filter((s) => (jobFilter === 'all' || s.jobId === jobFilter) && s.date >= from && s.date <= to)
      .sort((a, b) => (a.date > b.date ? 1 : -1))
      .forEach((s) => rows.push([
        s.date, state.jobs.find((j) => j.id === s.jobId)?.name, s.roleName,
        num(s.cash).toFixed(2), num(s.card).toFixed(2), num(s.autoGrat).toFixed(2), shiftTips(s).toFixed(2),
        num(s.hours), tipsPerHour(s).toFixed(2), s.useWage ? num(s.wage).toFixed(2) : '',
        s.sales, s.salesType, s.covers, s.tipOut,
        (s.shiftType || []).join(' + '), s.weather, s.events, s.section, s.vibe || '', s.note,
      ]))
    download(`tips_${from}_to_${to}.csv`, toCSV(rows))
  }
  return (
    <details className="card">
      <summary>Export shifts (tip proof)</summary>
      <div className="grid2">
        <label className="field"><span>From</span><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
        <label className="field"><span>To</span><input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label>
      </div>
      <button className="primary" onClick={run}>Download spreadsheet</button>
    </details>
  )
}

// PAYCHECK LOG: only for jobs where card tips come on a paycheck.
// Compares the tips on the paycheck with the card tips you tracked for that period.
function PaycheckLog({ state, update }) {
  const payJobs = state.jobs.filter((j) => j.tipsRule === 'paycheck')
  const [jobId, setJobId] = useState(payJobs[0]?.id || '')
  const [payDate, setPayDate] = useState(today())
  const [amount, setAmount] = useState('')
  const [note, setNote] = useState('')
  const [custom, setCustom] = useState(null) // { start, end } when changed by hand
  if (payJobs.length === 0) return null

  const job = payJobs.find((j) => j.id === jobId) || payJobs[0]
  const period = custom || paycheckPeriod(job, payDate)
  const tracked = (jid, p) =>
    state.shifts.filter((s) => s.jobId === jid && inRange(s.date, p)).reduce((a, s) => a + num(s.card), 0)

  const add = () => {
    if (amount === '') return
    update((s) => {
      s.paychecks.push({ id: uid(), jobId: job.id, payDate, start: period.start, end: period.end, amount: num(amount), note })
    })
    setAmount(''); setNote(''); setCustom(null)
  }

  return (
    <details className="card">
      <summary>Paycheck log</summary>
      <p className="hint">Log the tips on each paycheck (after deductions) and compare them with the card tips you tracked.</p>
      {payJobs.length > 1 && (
        <label className="field"><span>Job</span>
          <select value={job.id} onChange={(e) => { setJobId(e.target.value); setCustom(null) }}>
            {payJobs.map((j) => <option key={j.id} value={j.id}>{j.name}</option>)}
          </select>
        </label>
      )}
      <div className="grid2">
        <label className="field"><span>Pay date</span>
          <input type="date" value={payDate} onChange={(e) => { setPayDate(e.target.value); setCustom(null) }} /></label>
        <label className="field"><span>Tips on this paycheck ($)</span>
          <input type="number" inputMode="decimal" min="0" value={amount} onChange={(e) => setAmount(e.target.value)} /></label>
      </div>
      <div className="grid2">
        <label className="field"><span>Covers shifts from</span>
          <input type="date" value={period.start} onChange={(e) => setCustom({ ...period, start: e.target.value })} /></label>
        <label className="field"><span>to</span>
          <input type="date" value={period.end} onChange={(e) => setCustom({ ...period, end: e.target.value })} /></label>
      </div>
      <p className="hint">Card tips you tracked in this period: {money(tracked(job.id, period))}</p>
      <label className="field"><span>Note (tax, fees, deductions...)</span>
        <input value={note} onChange={(e) => setNote(e.target.value)} /></label>
      <button className="primary" onClick={add}>Save paycheck</button>

      {state.paychecks.length > 0 && (
        <ul className="list">
          {[...state.paychecks].sort((a, b) => (a.payDate < b.payDate ? 1 : -1)).map((p) => {
            const t = tracked(p.jobId, p)
            const diff = p.amount - t
            return (
              <li key={p.id}>
                <div>
                  <strong>{prettyDate(p.payDate)}</strong> · {state.jobs.find((j) => j.id === p.jobId)?.name}
                  <div className="hint">
                    Shifts {prettyDate(p.start)} to {prettyDate(p.end)} · Paycheck {money(p.amount)} · Tracked {money(t)} · Difference {money(diff)}
                    {p.note && ` · ${p.note}`}
                  </div>
                </div>
                <button className="link danger" onClick={() => update((s) => { s.paychecks = s.paychecks.filter((x) => x.id !== p.id) })}>Delete</button>
              </li>
            )
          })}
        </ul>
      )}
    </details>
  )
}

// TIME OFF LIST
function TimeOffList({ state, update, jobName }) {
  if (state.timeOff.length === 0) return null
  return (
    <details className="card">
      <summary>Time off</summary>
      <ul className="list">
        {[...state.timeOff].sort((a, b) => (a.start < b.start ? 1 : -1)).map((t) => (
          <li key={t.id}>
            <div>
              <strong>{t.type}</strong> · {jobName(t.jobId)}
              <div className="hint">{t.start === t.end ? prettyDate(t.start) : `${prettyDate(t.start)} to ${prettyDate(t.end)}`}</div>
            </div>
            <button className="link danger" onClick={() => update((s) => { s.timeOff = s.timeOff.filter((x) => x.id !== t.id) })}>Delete</button>
          </li>
        ))}
      </ul>
    </details>
  )
}
