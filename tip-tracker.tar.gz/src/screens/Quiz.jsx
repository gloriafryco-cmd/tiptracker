import { useState } from 'react'
import { newJob, uid, WEEKDAYS } from '../store.js'

// INTAKE QUIZ: asks about one job, one question per screen.
// Runs for a new job, and again from Settings ("Redo my job preferences")
// with the current answers filled in.

const SALES_HELP = {
  net: 'Net sales = gross sales minus discounts, comps and voids. Tax and tips are usually not included.',
  gross: 'Gross sales = everything rung in before discounts, comps and voids. Tax and tips are usually not included.',
}

const SPLIT_CHOICES = [
  ['own', 'I keep my own tips'],
  ['pool', "I'm in a tip pool"],
  ['tipout', 'I tip out support staff'],
  ['other', 'Other'],
]

const QUICK_ROLES = ['Server', 'Bartender']

export default function Quiz({ state, jobId, onSave, onCancel }) {
  const existing = state.jobs.find((j) => j.id === jobId)
  const [draft, setDraft] = useState(() => (existing ? structuredClone(existing) : newJob('')))
  const [step, setStep] = useState(0)
  const [newRole, setNewRole] = useState('')
  const set = (patch) => setDraft((d) => ({ ...d, ...patch }))
  const defaults = newJob()
  const others = state.jobs.filter((j) => j.id !== draft.id)

  const toggleRole = (name) => {
    const has = draft.roles.find((r) => r.name === name)
    set({
      roles: has
        ? draft.roles.filter((r) => r.name !== name)
        : [...draft.roles, { id: uid(), name, wage: 0 }],
    })
  }
  const addRole = () => {
    const name = newRole.trim()
    if (!name || draft.roles.some((r) => r.name.toLowerCase() === name.toLowerCase())) return
    set({ roles: [...draft.roles, { id: uid(), name, wage: 0 }] })
    setNewRole('')
  }

  // Each step: the question, what it shows, and which answers "use the default" resets.
  const steps = [
    {
      title: 'What is this job called, and which roles do you work here?',
      keys: ['roles'],
      body: (
        <>
          {!existing && others.length > 0 && (
            <label className="field">
              <span>Copy settings from another job (optional)</span>
              <select
                defaultValue=""
                onChange={(e) => {
                  const src = state.jobs.find((j) => j.id === e.target.value)
                  if (src) {
                    setDraft({
                      ...structuredClone(src),
                      id: draft.id,
                      name: draft.name,
                      archived: false,
                      roles: src.roles.map((r) => ({ ...r, id: uid() })),
                    })
                  }
                }}
              >
                <option value="">Start fresh</option>
                {others.map((j) => (
                  <option key={j.id} value={j.id}>{j.name}</option>
                ))}
              </select>
            </label>
          )}
          <label className="field">
            <span>Restaurant or job name</span>
            <input value={draft.name} placeholder="e.g. The Anchor" onChange={(e) => set({ name: e.target.value })} />
          </label>
          <div className="field">
            <span>Roles (pick all you work)</span>
            <div className="chips">
              {QUICK_ROLES.map((name) => (
                <button
                  key={name}
                  className={draft.roles.some((r) => r.name === name) ? 'chip on' : 'chip'}
                  onClick={() => toggleRole(name)}
                >
                  {name}
                </button>
              ))}
              {draft.roles
                .filter((r) => !QUICK_ROLES.includes(r.name))
                .map((r) => (
                  <button key={r.id} className="chip on" onClick={() => toggleRole(r.name)}>
                    {r.name} ✕
                  </button>
                ))}
            </div>
            <div className="row">
              <input
                value={newRole}
                placeholder="Other role (Manager, Host, Barback...)"
                onChange={(e) => setNewRole(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addRole()}
              />
              <button onClick={addRole}>Add</button>
            </div>
          </div>
        </>
      ),
    },
    {
      title: 'What is your hourly wage for each role?',
      keys: [],
      body: (
        <>
          <p className="hint">This is the hourly wage your employer pays, not tips. Leave a role at 0 if you don't want to track it.</p>
          {draft.roles.length === 0 && <p className="hint">Go back and pick at least one role.</p>}
          {draft.roles.map((r, i) => (
            <label className="field" key={r.id}>
              <span>{r.name} hourly wage ($)</span>
              <input
                type="number" inputMode="decimal" min="0" step="0.01"
                value={r.wage}
                onChange={(e) => {
                  const roles = [...draft.roles]
                  roles[i] = { ...r, wage: e.target.value }
                  set({ roles })
                }}
              />
            </label>
          ))}
        </>
      ),
    },
    {
      title: 'When do you get your tips?',
      keys: ['tipsRule', 'cardTipsRule', 'cardTipsWeekday', 'cardTipsNote'],
      body: (
        <>
          <Choice
            value={draft.tipsRule}
            onChange={(v) => set({ tipsRule: v })}
            options={[
              ['cash', 'All tips given as cash at the end of the shift'],
              ['paycheck', 'Cash at the end of the shift, card tips on the paycheck'],
            ]}
          />
          {draft.tipsRule === 'paycheck' && (
            <>
              <h3>How are your card tips paid?</h3>
              <Choice
                value={draft.cardTipsRule}
                onChange={(v) => set({ cardTipsRule: v })}
                options={[
                  ['weekly', "Each week's card tips are paid on a set weekday"],
                  ['withPaycheck', 'With the regular paycheck for that pay period'],
                  ['other', 'Other'],
                ]}
              />
              {draft.cardTipsRule === 'weekly' && (
                <label className="field">
                  <span>Which weekday?</span>
                  <select value={draft.cardTipsWeekday} onChange={(e) => set({ cardTipsWeekday: Number(e.target.value) })}>
                    {WEEKDAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}
                  </select>
                </label>
              )}
              {draft.cardTipsRule === 'other' && (
                <label className="field">
                  <span>Note</span>
                  <input value={draft.cardTipsNote} onChange={(e) => set({ cardTipsNote: e.target.value })} />
                </label>
              )}
            </>
          )}
        </>
      ),
    },
    {
      title: 'How do you want to enter hours?',
      keys: ['hoursFormat'],
      body: (
        <Choice
          value={draft.hoursFormat}
          onChange={(v) => set({ hoursFormat: v })}
          options={[
            ['decimal', 'As a number, like 6.5'],
            ['hm', 'As hours and minutes, like 6 h 30 m'],
          ]}
        />
      ),
    },
    {
      title: 'When does your week start, and how often is your hourly wage paid?',
      keys: ['weekStart', 'wageSchedule', 'wageStartDate', 'wageLagDays'],
      body: (
        <>
          <label className="field">
            <span>My work week starts on</span>
            <select value={draft.weekStart} onChange={(e) => set({ weekStart: Number(e.target.value) })}>
              {WEEKDAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}
            </select>
          </label>
          <h3>How often is your hourly wage paid?</h3>
          <Choice
            value={draft.wageSchedule}
            onChange={(v) => set({ wageSchedule: v })}
            options={[
              ['weekly', 'Weekly'],
              ['biweekly', 'Every 2 weeks'],
              ['semimonthly', 'Twice a month (1st to 15th, 16th to end of month)'],
              ['monthly', 'Monthly'],
            ]}
          />
          {draft.wageSchedule === 'biweekly' && (
            <label className="field">
              <span>First day of any pay period</span>
              <input type="date" value={draft.wageStartDate} onChange={(e) => set({ wageStartDate: e.target.value })} />
            </label>
          )}
          <label className="field">
            <span>The check arrives this many days after the pay period ends (optional)</span>
            <input type="number" min="0" inputMode="numeric" value={draft.wageLagDays} onChange={(e) => set({ wageLagDays: e.target.value })} />
          </label>
        </>
      ),
    },
    {
      title: 'Does your report show net or gross sales?',
      keys: ['salesType'],
      body: (
        <>
          <Choice
            value={draft.salesType}
            onChange={(v) => set({ salesType: v })}
            options={[
              ['net', 'Net sales'],
              ['gross', 'Gross sales'],
            ]}
          />
          <p className="hint">{SALES_HELP[draft.salesType]}</p>
        </>
      ),
    },
    {
      title: 'How are tips split at this job?',
      keys: ['tipSplit', 'tipSplitNote'],
      body: (
        <>
          <Choice value={draft.tipSplit} onChange={(v) => set({ tipSplit: v })} options={SPLIT_CHOICES} />
          <label className="field">
            <span>Note (optional)</span>
            <input value={draft.tipSplitNote} placeholder="e.g. 3% of sales to the bar" onChange={(e) => set({ tipSplitNote: e.target.value })} />
          </label>
        </>
      ),
    },
    {
      title: 'What is your weekly tip goal?',
      keys: ['weeklyGoal', 'goalWhenOff', 'nudge'],
      body: (
        <>
          <label className="field">
            <span>My weekly tip goal ($)</span>
            <input type="number" inputMode="decimal" min="0" value={draft.weeklyGoal} onChange={(e) => set({ weeklyGoal: e.target.value })} />
          </label>
          <h3>When I take time off, my weekly goal</h3>
          <Choice
            value={draft.goalWhenOff}
            onChange={(v) => set({ goalWhenOff: v })}
            options={[
              ['shrink', 'Shrinks with my days off'],
              ['stay', 'Stays the same'],
            ]}
          />
          <label className="switch">
            <input type="checkbox" checked={draft.nudge} onChange={(e) => set({ nudge: e.target.checked })} />
            <span>Nudge me to pick up a shift near the end of the week</span>
          </label>
        </>
      ),
    },
  ]

  const s = steps[step]
  const last = step === steps.length - 1

  const finish = (d) => {
    const job = { ...d, name: d.name.trim() || 'My job', setupDone: true }
    job.roles = job.roles.length ? job.roles : defaults.roles
    job.roles = job.roles.map((r) => ({ ...r, wage: Number(r.wage) || 0 }))
    job.weeklyGoal = Number(job.weeklyGoal) || 0
    job.wageLagDays = Number(job.wageLagDays) || 0
    onSave(job)
  }

  const next = (d = draft) => (last ? finish(d) : setStep(step + 1))

  const useDefault = () => {
    const patch = {}
    for (const k of s.keys) patch[k] = structuredClone(defaults[k])
    const d = { ...draft, ...patch }
    setDraft(d)
    next(d)
  }

  return (
    <section className="quiz">
      <p className="step-count">
        {existing ? 'Redo my job preferences' : 'Set up a job'} · Question {step + 1} of {steps.length}
      </p>
      <h2>{s.title}</h2>
      {s.body}
      <div className="actions">
        <button className="primary" onClick={() => next()}>{last ? 'Save job' : 'Next'}</button>
        <button className="ghost" onClick={useDefault}>Not sure, use the default</button>
      </div>
      <div className="actions small">
        {step > 0 && <button className="ghost" onClick={() => setStep(step - 1)}>Back</button>}
        <button className="ghost" onClick={onCancel}>Cancel</button>
      </div>
    </section>
  )
}

// One-pick list of choices
export function Choice({ value, onChange, options }) {
  return (
    <div className="choices">
      {options.map(([v, label]) => (
        <button key={v} className={value === v ? 'choice on' : 'choice'} onClick={() => onChange(v)}>
          {label}
        </button>
      ))}
    </div>
  )
}
