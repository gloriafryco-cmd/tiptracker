// STORE: everything the app saves, plus the math.
// Data is saved in this browser only (localStorage). Nothing is sent anywhere.

const KEY = 'tipTracker.v1'

export const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)

// JOB DEFAULTS: what "Not sure, use the default" picks.
export function newJob(name = 'My job') {
  return {
    id: uid(),
    name,
    archived: false,
    setupDone: false,
    roles: [
      { id: uid(), name: 'Server', wage: 2.13 },
    ],
    tipsRule: 'cash', // 'cash' = all tips as cash at the end of the shift, 'paycheck' = cash at the end of the shift, card tips on the paycheck
    cardTipsRule: 'weekly', // 'weekly' | 'withPaycheck' | 'other'
    cardTipsWeekday: 3, // Wednesday
    cardTipsNote: '',
    hoursFormat: 'decimal', // 'decimal' (6.5) | 'hm' (6 h 30 m)
    weekStart: 1, // Monday
    wageSchedule: 'semimonthly', // 'weekly' | 'biweekly' | 'semimonthly' | 'monthly'
    wageStartDate: '',
    wageLagDays: 0,
    salesType: 'net',
    tipSplit: 'own', // 'own' | 'pool' | 'tipout' | 'other'
    tipSplitNote: '',
    weeklyGoal: 0,
    goalWhenOff: 'shrink', // 'shrink' | 'stay'
    nudge: true,
    trackAutoGrat: false,
  }
}

const EMPTY = {
  jobs: [],
  shifts: [],
  regulars: [],
  paychecks: [],
  timeOff: [],
  prefs: { theme: 'auto', largeText: false },
  last: { jobId: null, roleId: null, useWage: false },
}

export function loadState() {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return structuredClone(EMPTY)
    return { ...structuredClone(EMPTY), ...JSON.parse(raw) }
  } catch {
    return structuredClone(EMPTY)
  }
}

export function saveState(state) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state))
  } catch {
    // Storage full or blocked: the app keeps working for this visit.
  }
}

export function eraseAll() {
  try { localStorage.removeItem(KEY) } catch {}
  return structuredClone(EMPTY)
}

// ---------- DATES (all dates are "YYYY-MM-DD" in your own time zone) ----------

export const toDate = (s) => {
  const [y, m, d] = s.split('-').map(Number)
  return new Date(y, m - 1, d)
}
export const toStr = (d) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
export const today = () => toStr(new Date())
export const addDays = (s, n) => {
  const d = toDate(s)
  d.setDate(d.getDate() + n)
  return toStr(d)
}
export const prettyDate = (s) =>
  toDate(s).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })

// WEEK: the 7 days containing a date, using the job's week start day.
export function weekRange(dateStr, weekStart = 1) {
  const day = toDate(dateStr).getDay()
  const back = (day - weekStart + 7) % 7
  const start = addDays(dateStr, -back)
  return { start, end: addDays(start, 6) }
}

export const inRange = (d, r) => d >= r.start && d <= r.end

// HOURLY WAGE PAY PERIOD that contains a date.
export function wagePeriod(job, dateStr) {
  const d = toDate(dateStr)
  switch (job.wageSchedule) {
    case 'weekly':
      return weekRange(dateStr, job.weekStart)
    case 'biweekly': {
      const anchor = job.wageStartDate || '2026-01-05'
      const diff = Math.round((toDate(dateStr) - toDate(anchor)) / 86400000)
      const k = Math.floor(diff / 14)
      const start = addDays(anchor, k * 14)
      return { start, end: addDays(start, 13) }
    }
    case 'monthly': {
      const start = toStr(new Date(d.getFullYear(), d.getMonth(), 1))
      const end = toStr(new Date(d.getFullYear(), d.getMonth() + 1, 0))
      return { start, end }
    }
    default: {
      // twice a month: 1st to 15th, 16th to end of month
      if (d.getDate() <= 15) {
        return {
          start: toStr(new Date(d.getFullYear(), d.getMonth(), 1)),
          end: toStr(new Date(d.getFullYear(), d.getMonth(), 15)),
        }
      }
      return {
        start: toStr(new Date(d.getFullYear(), d.getMonth(), 16)),
        end: toStr(new Date(d.getFullYear(), d.getMonth() + 1, 0)),
      }
    }
  }
}

// PAYCHECK TIP PERIOD: which shifts a paycheck should cover.
// Weekly card tips: the last full week that ended before pay day.
// With the regular paycheck: the last wage period that ended
// at least "lag" days before pay day.
export function paycheckPeriod(job, payDate) {
  if (job.cardTipsRule === 'withPaycheck') {
    const target = addDays(payDate, -(Number(job.wageLagDays) || 0))
    let p = wagePeriod(job, target)
    if (p.end > target) p = wagePeriod(job, addDays(p.start, -1))
    return p
  }
  const target = addDays(payDate, -1)
  let p = weekRange(target, job.weekStart)
  if (p.end > target) p = weekRange(addDays(p.start, -1), job.weekStart)
  return p
}

// ---------- MONEY MATH ----------

export const num = (v) => {
  const n = parseFloat(v)
  return Number.isFinite(n) ? n : 0
}
export const money = (n) =>
  (n < 0 ? '-$' : '$') + Math.abs(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })

export const shiftTips = (s) => num(s.cash) + num(s.card) + num(s.autoGrat)
export const shiftWagePay = (s) => (s.useWage ? num(s.wage) * num(s.hours) : 0)
export const tipsPerHour = (s) => (num(s.hours) > 0 ? shiftTips(s) / num(s.hours) : 0)
export const perHourWithWage = (s) =>
  num(s.hours) > 0 ? (shiftTips(s) + shiftWagePay(s)) / num(s.hours) : 0

// Hours worked from start and end times ("HH:MM"), including past midnight.
export function hoursFromTimes(start, end) {
  if (!start || !end) return 0
  const [sh, sm] = start.split(':').map(Number)
  const [eh, em] = end.split(':').map(Number)
  let mins = eh * 60 + em - (sh * 60 + sm)
  if (mins <= 0) mins += 24 * 60
  return Math.round((mins / 60) * 100) / 100
}

export const fmtHours = (h, format) => {
  if (format === 'hm') {
    const whole = Math.floor(h)
    const mins = Math.round((h - whole) * 60)
    return `${whole}h ${mins}m`
  }
  return `${Math.round(h * 100) / 100}h`
}

// WEEKLY GOAL: shrinks with days off (if the job says so).
export function daysOffIn(state, jobId, range) {
  const days = new Set()
  for (const t of state.timeOff) {
    if (t.jobId !== jobId) continue
    let d = t.start
    while (d <= t.end) {
      if (inRange(d, range)) days.add(d)
      d = addDays(d, 1)
    }
  }
  return days.size
}

export function weekProgress(state, job, dateStr) {
  const range = weekRange(dateStr, job.weekStart)
  const shifts = state.shifts.filter((s) => s.jobId === job.id && inRange(s.date, range))
  const tips = shifts.reduce((a, s) => a + shiftTips(s), 0)
  const off = daysOffIn(state, job.id, range)
  const base = num(job.weeklyGoal)
  const goal = job.goalWhenOff === 'shrink' ? (base * (7 - off)) / 7 : base
  return { range, tips, goal, off, shifts: shifts.length }
}

// CSV EXPORT
export function toCSV(rows) {
  const esc = (v) => {
    const s = v == null ? '' : String(v)
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
  }
  return rows.map((r) => r.map(esc).join(',')).join('\n')
}

export function download(filename, text) {
  const blob = new Blob([text], { type: 'text/csv' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
